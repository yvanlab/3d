                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:42528
 1.75mm Filament Clip by walter is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Small clip that snap on to spools and holds the end of the filament to prevent it from unraveling.  There are several versions, should work with spools from the following suppliers (at least in 2013):

**added 2013:**
* [Octave*](http://amzn.to/2f0GrDh)
* [Up!*](http://amzn.to/2f0IaZ6)
* [Ultimachine](https://ultimachine.com/)
* 3DD

**added 2016:**
* [Inland 1kg*](http://amzn.to/2i5AOt4) (black spool)
* [Intservo 1kg*](http://amzn.to/2irwYqx) (transparent spool)
* [Atomic Filament](https://atomicfilament.com/) (18 spoke, 32 spoke, and 1lb spools)

**added 2017:**
* [Colorfabb*](http://amzn.to/2sjfg1w) and [Filamentum*](http://amzn.to/2ssPqYF)
* [Hatchbox 1kg*](http://amzn.to/2sYOcp8)


**affiliate link*
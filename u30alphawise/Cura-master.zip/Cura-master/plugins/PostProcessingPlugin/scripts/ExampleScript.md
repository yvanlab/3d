A good example script is SearchAndReplace.py.
If you have any questions please ask them at: 
https://github.com/Ultimaker/Cura/issues 
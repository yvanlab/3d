                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3432950
SD Card Alfawise U30 by terrano306 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a microSD to SD Card adapter for Alfawise U30.

I made  this because I do not like microSD cards and because I do not find it practical the card reader to be on the back of the printer.

I used this card extension: 
https://www.ebay.com/itm/Wholesale-TF-Micro-SD-To-TF-Card-Extension-Cable-Adapter-Flexible-Extender-48cm/173709980464?ssPageName=STRK%3AMEBIDX%3AIT&_trksid=p2057872.m2749.l2649

# Print Settings

Printer Brand: Creality
Printer: CR-10S
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 20%
Filament_brand: RepRap
Filament_color: Red
Filament_material: PLA
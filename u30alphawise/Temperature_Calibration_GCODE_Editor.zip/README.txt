                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1579403
Temperature Calibration GCODE Editor by orubap is licensed under the Creative Commons - Attribution - No Derivatives license.
http://creativecommons.org/licenses/by-nd/3.0/

# Summary

A while ago I started calibrating my extruder temperature for my various rolls of filament, which (for those who don't know) involves running a single print that gradually changes temperature and then reviewing afterward where the print looks the best in terms of layer adhesion, overhangs, bridging, etc. To do this, we need to edit our sliced gcode file before sending it to the printer and insert the various temperatures we'd like the extruder to reach. While it's not particularly hard to edit the gcode file by hand in a text editor I wrote a python script to automate the process.

<br>
My routine now whenever I get a new roll of filament is to:
1. check the recommended temperature range as given on the filament
2. create a customised model with that range
3. slice the model
4. run the gcode file through the python script
5. print
6. review the print then mark the optimal temp on the side of the spool

Some examples to use for a customised temp tower can be found via: [ellipticaloptician](https://www.thingiverse.com/thing:2397822), [eibwen](https://www.thingiverse.com/thing:915435), 

<br>
<h3>Instructions</h3>
When slicing your stl file it is a good idea (but not strictly necessary) to set the printing temperature in your slicer settings to the starting temperature you intend to test.

To use the script you'll need to have [python](https://www.python.org/downloads/) installed. Simply drag and drop your gcode file onto the python scripts icon then follow the prompts to enter three parameters:
1. your starting temperature
2. your final temperature
3. the amount at which the temperature should change

The script will then tell you which temps will print at which height.

<br>
<h3>Which Slicer?</h3>
The script will auto-detect and handle output from a few different slicers (and across a few different versions). If you receive the message saying your slicer "isn't yet supported", you can upload your gcode somewhere and send me the link and I'll add it.

<br>
<h3>Edits</h3>
26/05/2016 - updated script (more robust)
21/09/2016 - updated script to handle output from another slicer
19/06/2017 - added a separate script for CURA users
06/12/2017 - consolidated the separate versions into one. added: auto-detection for different slicer output; various safety checks; and a couple of requested features

<br>
<h3>Disclaimer</h3>
Please only use this script if you understand what you're doing. I accept no responsibility if you damage your printer!
                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2979733
Alfawise U20 & U30 bed knobs by AdryJay is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This knob / thumbdial / thumbwheel is designed for the Alfawise U20 / U30 heatbed.

Other models here on Thingiverse (for the CR-10) are designed for different knobs and don't work with the Alfawise U20 / U30.

This upgrade is designed to include the 18 teeth original adjusting knobs. You don't need to scale it, tolerances are already good. I tried to make it printable as fast as possible, it will take 1,5/2 hours to finish.

Update | Added a smaller variant because the original one was too big for the Alfawise U30.

<a href="https://www.gearbest.com/3d-printers-3d-printer-kits/pp_1841229.html?wid=1433363&lkid=14682927">BUY</a> - Alfawise U20 3D printer
<a href="https://it.gearbest.com/3d-printers-3d-printer-kits/pp_009954647322.html?lkid=17502807">BUY</a> - Alfawise U30 3D printer
<a href="https://www.thingiverse.com/thing:3007875">LEARN MORE</a> - If you own an Alfawise U20, I strongly suggest you to buy TL-smoothers to fix the salmon skin issue
<a href="https://www.thingiverse.com/thing:3010366">DOWNLOAD</a> - Filament guide upgrade designed by me